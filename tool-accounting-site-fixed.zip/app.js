const KEY = "toolRecordsV1";
let photo = "";

const $ = id => document.getElementById(id);

const load = () => {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || [];
  } catch {
    return [];
  }
};

const save = records => localStorage.setItem(KEY, JSON.stringify(records));
const fmt = value => new Date(value).toLocaleString("ru-RU");

const params = new URLSearchParams(window.location.search);
const toolFromUrl = (params.get("tool") || "").trim();

function msg(id, text = "", ok = true) {
  const element = $(id);
  element.textContent = text;
  element.className = text ? `message ${ok ? "ok" : "err"}` : "message";
}

function makeRecordCard(record) {
  const card = document.createElement("div");
  card.className = "record";

  if (record.photo) {
    const image = document.createElement("img");
    image.src = record.photo;
    image.alt = `Инструмент ${record.toolId}`;
    card.appendChild(image);
  }

  const content = document.createElement("div");
  content.className = "record-content";

  const title = document.createElement("b");
  title.textContent = record.toolId;
  content.appendChild(title);

  const meta = document.createElement("div");
  meta.className = "meta";
  meta.append(`Взял: ${record.employee}`);
  meta.appendChild(document.createElement("br"));
  meta.append(`Выдан: ${fmt(record.issuedAt)}`);
  if (record.returnedAt) {
    meta.appendChild(document.createElement("br"));
    meta.append(`Возвращён: ${fmt(record.returnedAt)}`);
  }
  content.appendChild(meta);

  const status = document.createElement("div");
  status.className = record.status === "not_returned" ? "out" : "in";
  status.textContent = record.status === "not_returned" ? "Не возвращён" : "Возвращён";
  content.appendChild(status);

  card.appendChild(content);
  return card;
}

function renderList(id, records) {
  const box = $(id);
  box.replaceChildren();

  if (!records.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Пусто";
    box.appendChild(empty);
    return;
  }

  records.forEach(record => box.appendChild(makeRecordCard(record)));
}

function getActiveRecord(toolId) {
  return [...load()].reverse().find(record =>
    record.toolId === toolId && record.status === "not_returned"
  );
}

function render() {
  const records = load();
  const active = records.filter(record => record.status === "not_returned");
  $("activeCount").textContent = active.length;
  renderList("activeList", active);
  renderList("historyList", [...records].reverse());
}

function setToolMode() {
  const issueCard = $("issueCard");
  const returnCard = $("returnCard");
  const statusCard = $("nfcStatusCard");

  msg("issueMessage");
  msg("returnMessage");

  // Без NFC-параметра остаётся ручной режим с двумя формами.
  if (!toolFromUrl) {
    statusCard.hidden = true;
    issueCard.hidden = false;
    returnCard.hidden = false;
    return;
  }

  statusCard.hidden = false;
  $("currentToolLabel").textContent = toolFromUrl;

  const activeRecord = getActiveRecord(toolFromUrl);

  if (activeRecord) {
    // Уже выдан: показываем только возврат.
    issueCard.hidden = true;
    returnCard.hidden = false;
    $("issueToolId").value = "";
    $("returnToolId").value = toolFromUrl;
    $("modeLabel").textContent = `Сейчас у: ${activeRecord.employee}`;
    msg("returnMessage", "Инструмент готов к возврату", true);
  } else {
    // Свободен: показываем только выдачу.
    issueCard.hidden = false;
    returnCard.hidden = true;
    $("issueToolId").value = toolFromUrl;
    $("returnToolId").value = "";
    $("modeLabel").textContent = "Инструмент свободен";
    msg("issueMessage", "Инструмент готов к выдаче", true);
  }
}

$("photo").onchange = event => {
  const file = event.target.files[0];
  if (!file) {
    photo = "";
    $("preview").hidden = true;
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    photo = reader.result;
    $("preview").src = photo;
    $("preview").hidden = false;
  };
  reader.readAsDataURL(file);
};

$("issueBtn").onclick = () => {
  const employee = $("employee").value.trim();
  const toolId = $("issueToolId").value.trim();

  if (!employee || !toolId) {
    return msg("issueMessage", "Укажи сотрудника и инструмент", false);
  }

  const records = load();
  if (records.some(record => record.toolId === toolId && record.status === "not_returned")) {
    setToolMode();
    return msg("returnMessage", "Этот инструмент уже выдан", false);
  }

  records.push({
    id: Date.now(),
    employee,
    toolId,
    photo,
    issuedAt: new Date().toISOString(),
    returnedAt: null,
    status: "not_returned"
  });
  save(records);

  $("employee").value = "";
  $("photo").value = "";
  $("preview").hidden = true;
  photo = "";

  render();
  setToolMode();
  msg("returnMessage", "Инструмент выдан. При возврате нажми «Вернуть»", true);
};

$("returnBtn").onclick = () => {
  const toolId = $("returnToolId").value.trim();
  const records = load();
  const record = [...records].reverse().find(item =>
    item.toolId === toolId && item.status === "not_returned"
  );

  if (!record) {
    return msg("returnMessage", "Инструмент не найден среди выданных", false);
  }

  record.status = "returned";
  record.returnedAt = new Date().toISOString();
  save(records);

  render();
  setToolMode();
  msg("issueMessage", "Возврат записан. Инструмент снова свободен", true);
};

$("clearBtn").onclick = () => {
  if (confirm("Удалить всю историю?")) {
    localStorage.removeItem(KEY);
    render();
    setToolMode();
  }
};

$("exportBtn").onclick = () => {
  const rows = [
    ["Инструмент", "Кто взял", "Выдан", "Возвращён", "Статус"],
    ...load().map(record => [
      record.toolId,
      record.employee,
      fmt(record.issuedAt),
      record.returnedAt ? fmt(record.returnedAt) : "",
      record.status === "not_returned" ? "Не возвращён" : "Возвращён"
    ])
  ];

  const csv = "\uFEFF" + rows
    .map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(";"))
    .join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "tool-history.csv";
  link.click();
  URL.revokeObjectURL(url);
};

render();
setToolMode();
